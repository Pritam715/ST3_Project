package signin;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class signin
 */
@WebServlet("/signin")
public class signin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		

		PrintWriter out=response.getWriter();

			String email= request.getParameter("email");
			String pass= request.getParameter("password");
			DBConnection abc=new  DBConnection();

			if(abc.check(email,pass))
			{
				  
				response.sendRedirect("main.jsp");  
				
			}
			else
			{
				out.print("Incorrect username and password");
			
			}
				
			
			
	
    

	
	}

}
