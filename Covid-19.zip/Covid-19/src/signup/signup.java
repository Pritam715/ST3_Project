package signup;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class signup
 */
@WebServlet("/signup")
public class signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   

		PrintWriter out=response.getWriter();
			
			String name= request.getParameter("user_name");
			String email= request.getParameter("user_email");
			String pass= request.getParameter("user_pass");
			String country= request.getParameter("user_country");
			String gender= request.getParameter("user_gender");
	
			DBConnection1 connect=new  DBConnection1();

			if(connect.check(name,email,pass,country,gender))
			{
				out.print("Data inserted");
				  
				response.sendRedirect("signin.jsp");  
				
			}
			else
			{
				out.print("Not Inserted");
			
			}
	
		
	
	}
		
}

