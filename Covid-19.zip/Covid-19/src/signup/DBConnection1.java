package signup;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;





public class DBConnection1 {

	public boolean check(String name,String email,String pass,String country,String gender)
	{
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user="system";
		String password="Pritam715";
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection(url,user,password);
			String sql="insert into users (name,email,password,country,gender) values(?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,name);
			ps.setString(2, email);
			ps.setString(3, pass);
			ps.setString(4, country);
			ps.setString(5, gender);
			ps.executeUpdate();
			ps.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}
}
